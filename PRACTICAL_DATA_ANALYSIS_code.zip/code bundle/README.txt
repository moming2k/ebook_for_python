Code present for chapters 2,3,4,5,6,7,8,9,10,11,12,13,and 14.

Chapter 1 does not have code.